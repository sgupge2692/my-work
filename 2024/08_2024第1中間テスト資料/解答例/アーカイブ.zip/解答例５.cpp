﻿#include <iostream>
using namespace std;

int main() {
    int num4, num3, num2, num1;
    int max;
    cin >> max;
    for (num4 = 1000; num4 <= max; num4++) {
        int isPrimeNumber = true;
        for (int i = 2; i <= num4 / 2; i++) {
            if (num4 % i == 0) {
                isPrimeNumber = false;
                break;
            }
        }
        if (isPrimeNumber == true) {
            num3 = num4 / 10;
            if (num3 == 1) {
                isPrimeNumber = false;
            }
            for (int i = 2; i <= num3 / 2; i++) {
                if (num3 % i == 0) {
                    isPrimeNumber = false;
                    break;
                }
            }
        }
        if (isPrimeNumber == true) {
            num2 = num3 / 10;
            if (num2 == 1) {
                isPrimeNumber = false;
            }
            for (int i = 2; i <= num2 / 2; i++) {
                if (num2 % i == 0) {
                    isPrimeNumber = false;
                    break;
                }
            }
        }
        if (isPrimeNumber == true) {
            num1 = num2 / 10;
            if (num1 == 1) {
                isPrimeNumber = false;
            }
            for (int i = 2; i <= num1 / 2; i++) {
                if (num1 % i == 0) {
                    isPrimeNumber = false;
                    break;
                }
            }
        }
        if (isPrimeNumber == true) {
            cout << num4 << endl;
        }
    }
    return 0;
}
