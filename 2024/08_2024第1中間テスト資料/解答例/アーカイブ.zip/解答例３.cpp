﻿#include <iostream>
using namespace std;

int main() {
    int travel_days;
    int budget;
    int interest;

    // ユーザーが日数／予算／興味を入力
    cin >> travel_days >> budget >> interest;

    switch (interest) {
    case 1:
        if (budget / travel_days >= 50) {
            cout << "オーストラリア" << endl;
        }
        if (budget / travel_days >= 20) {
            cout << "京都" << endl;
        }
        if (budget / travel_days >= 10) {
            cout << "長崎" << endl;
        }
        break;
    case 2:
        if (budget / travel_days >= 30) {
            cout << "北海道" << endl;
        }
        if (budget / travel_days >= 18) {
            cout << "鳥取砂丘" << endl;
        }
        if (budget / travel_days >= 15) {
            cout << "阿蘇" << endl;
        }
        break;
    case 3:
        if (budget / travel_days >= 70) {
            cout << "ローマ" << endl;
        }
        if (budget / travel_days >= 40) {
            cout << "アンコールワット" << endl;
        }
        if (budget / travel_days >= 30) {
            cout << "鎌倉" << endl;
        }
        break;
    default:
        cout << "入力エラー" << endl;
    }

    return 0;
}
