﻿#include <iostream>
using namespace std;

int main() {
    int points;             //違反点数
    int totalPoints = 0;    //これまでの違反点数の累積点数
    int noViolations = 0;   //無違反年数（違反0点の年数）

    for (int year = 1; year <= 10; year++) {
        cout << year << "年目　違反点数 ";
        cin >> points;
        totalPoints += points;
        
        if (points == 0) {
            noViolations++;
            if (noViolations >= 3) {
                cout << "_______状態：ゴールドドライバー";
                totalPoints = 0;
            }
            else {
                cout << "_______状態：優良ドライバー";
            }
        }
        else {
            noViolations = 0;
            if (totalPoints >= 10) {
                cout << "免許取消";
                return 0;
            }
            else if (totalPoints >= 5) {
                totalPoints = 0;
                cout << "_______状態：免停ドライバー" << "，累積点数：" << totalPoints << endl;
                if (year == 10) {
                    return 0;
                }
                year++;
                cout << year << "年目　状態：免停中________";
            }
            else {
                cout << "_______状態：一般ドライバー";
            }
        }
        cout << "，累積点数：" << totalPoints << endl;
    }
    return 0;
}
