﻿#include <iostream>
#include <math.h>
using namespace std;

int main() {
	int score;
	double point;
	cin >> score;
	double root_score = sqrt(score); //スコアの平方根

	point = root_score * 2.0 + score / 20.0;

	cout << point;
}