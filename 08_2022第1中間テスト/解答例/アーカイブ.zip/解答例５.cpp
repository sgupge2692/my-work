﻿#include <iostream>
using namespace std;

int main() {
	double data[5][6] = {
			{0, 13, 19, 5, 7, 19},
			{16, 15, 3, 15, 20, 18},
			{1, 3, 14, 17, 11, 15},
			{13, 16, 19, 5, 18, 16},
			{19, 13, 10, 5, 10, 18}};
	int a, b, n;
	double answer = 0.0;
	cin >> a >> b >> n;

	if (a == 1) {
		if (b == 1) {
			for (int i = 0; i < 6; i++) {
				answer += data[n][i];
			}
			answer /= 6.0;
		}
		else {
			for (int i = 0; i < 5; i++) {
				answer += data[i][n];
			}
			answer /= 5.0;
		}
	}
	else {
		if (b == 1) {
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 5; j++) {
					if (data[n][j] > data[n][j + 1]) {
						int tmp = data[n][j];
						data[n][j] = data[n][j + 1];
						data[n][j + 1] = tmp;
					}
				}
			}
			answer = (data[n][2] + data[n][3]) / 2.0;
		}
		else {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 4; j++) {
					if (data[j][n] > data[j + 1][n]) {
						int tmp = data[j][n];
						data[j][n] = data[j + 1][n];
						data[j + 1][n] = tmp;
					}
				}
			}
			answer = data[2][n];
		}
	}

	cout << answer;
}