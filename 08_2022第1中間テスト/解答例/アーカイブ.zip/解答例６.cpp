﻿#include <iostream>
using namespace std;

int main() {
	int point, patarn = 0;

	cin >> point;

	int board[62];
	for (int i = 0; i <= 20; i++) {
		board[i] = i;
	}
	for (int i = 21; i <= 40; i++) {
		board[i] = (i - 20) * 2;
	}
	for (int i = 41; i <= 60; i++) {
		board[i] = (i - 40) * 3;
	}
	board[61] = 50;
	for (int i = 0; i < 62; i++) {
		for (int j = 0; j < 62; j++) {
			for (int k = 0; k < 62; k++) {
				if (board[i] + board[j] + board[k] == point) {
					patarn++;
					//結果表示用
					/*
					int data[3] = { i,j,k };
					for(int n = 0; n < 3; n++) {
						if (data[n] == 0) {
							cout << "M_" << ",";
						}
						else if (data[n] < 21) {
							cout << "S";
							cout << data[n] << ",";
						}
						else if (data[n] < 41) {
							cout << "D";
							cout << data[n] -20 << ",";
						}
						else {
							cout << "T";
							cout << data[n] -40 << ",";
						}
					}
					cout << endl;
					/**/
				}
			}
		}
	}
	cout << patarn;
}