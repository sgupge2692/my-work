﻿#include <iostream>
using namespace std;

int main() {
	double data[5];

	for (int i = 0; i < 5; i++) {
		cin >> data[i];
	}

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 4; j++) {
			if (data[j] > data[j + 1]) {
				double tmp = data[j];
				data[j] = data[j + 1];
				data[j + 1] = tmp;
			}
		}
	}

	for (int i = 0; i < 5; i++) {
		cout << data[i] << endl;
	}
}