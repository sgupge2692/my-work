#include <iostream>
using namespace std;

int main() {
	int a, b, ans;
	cin >> a >> b;
	if (a > b) {
		ans = a;
	}
	else {
		ans = b;
	}
	while (true) {
		if (ans % a == 0 && ans % b == 0) {
			break;
		}
		ans++;
	}
	cout << ans << endl;
	return 0;
}